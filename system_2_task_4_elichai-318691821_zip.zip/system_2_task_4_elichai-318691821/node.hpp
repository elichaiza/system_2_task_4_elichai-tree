//elichaiza@gmail.com
//ID:318691821
#ifndef NODE_H
#define NODE_H
#include <iostream>
#include <vector>
#include <SFML/Graphics.hpp>

using namespace std;

template <typename T>

class node {
private:
    T type_and_value;
    int max_size{};
    vector<node<T>*>childrens;

public:
    node(T type,int max_size=2) {
        this->type_and_value=type;
        this->max_size=max_size;
        cout<<"Creating a new node" << type <<  endl;
    }
    ~node() {}

    T getType() {
        return this->type_and_value;
    }

    int get_max_size() {
        return this->max_size;
    }

    vector<node<T>*> get_childrens() {
         vector<node<T>*> ans;
        if(this->childrens.empty()==true) {
            return ans ;
        }
        for(size_t i=0;i<this->childrens.size();i++) {
            ans.push_back(childrens[i]);
        }
        return  ans;
    }

    void add_child( node *child) {
        if(static_cast<int>(this->childrens.size()) == max_size) {
            cout<<"Sorry, the child cannot be added because the father's size has reached its maximum"<<endl;
            return;
        }
        this->childrens.push_back(child);
         cout<<"the node adding successfully to the tree" <<endl;
    }
};

#endif //NODE_H
