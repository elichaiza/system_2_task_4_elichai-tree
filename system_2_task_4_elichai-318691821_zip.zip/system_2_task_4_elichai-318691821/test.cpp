//elichaiza@gmail.com
//ID:318691821

#include "doctest.h"
#include "complex_number.h"
#include "node.hpp"
#include "tree.hpp"
#include <iostream>
#include <sstream>
#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN

using namespace std;

// Helper function to create a more complex test tree
node<int>* create_complex_test_tree() {
    node<int>* root = new node<int>(1);
    node<int>* child1 = new node<int>(2);
    node<int>* child2 = new node<int>(3);
    node<int>* child3 = new node<int>(4);

    root->add_child(child1);
    root->add_child(child2);
    root->add_child(child3);

    node<int>* grandchild1 = new node<int>(5);
    node<int>* grandchild2 = new node<int>(6);
    node<int>* grandchild3 = new node<int>(7);

    child1->add_child(grandchild1);
    child1->add_child(grandchild2);
    child2->add_child(grandchild3);

    node<int>* greatGrandchild1 = new node<int>(8);
    grandchild1->add_child(greatGrandchild1);

    return root;
}

// test to create nodes
TEST_CASE("Creating nodes") {
    node<int> n1(1);
    CHECK(n1.getType() == 1);
    CHECK(n1.get_max_size() == 2);

    node<int> n2(2, 5);
    CHECK(n2.getType() == 2);
    CHECK(n2.get_max_size() == 5);
}

//test to adding nodes
TEST_CASE("Adding children to node") {
    node<int> parent(1);
    node<int> child1(2);
    node<int> child2(3);

    parent.add_child(&child1);
    parent.add_child(&child2);

    auto children = parent.get_childrens();
    CHECK(children.size() == 2);
    CHECK(children[0]->getType() == 2);
    CHECK(children[1]->getType() == 3);
}

// test to the check the max children
TEST_CASE("Adding children with maximum size") {
    node<int> parent(1, 2); // max_size is 2
    node<int> child1(2);
    node<int> child2(3);
    node<int> child3(4);

    parent.add_child(&child1);
    parent.add_child(&child2);

    // Trying to add a third child should fail
    parent.add_child(&child3);

    auto children = parent.get_childrens();
    CHECK(children.size() == 2); // Only 2 children should be added
    CHECK(children[0]->getType() == 2);
    CHECK(children[1]->getType() == 3);
}

// Tests for collecting children when they are empty
TEST_CASE("Getting children when empty") {
    node<int> parent(1);
    auto children = parent.get_childrens();
    CHECK(children.size() == 0); // No children should be present
}

// Tests the storage capacity of children
 TEST_CASE("Child capacity") {
    node<int> parent(1, 3); // max_size is 3
    node<int> child1(2);
    node<int> child2(3);
    node<int> child3(4);
    node<int> child4(5);

    parent.add_child(&child1);
    parent.add_child(&child2);
    parent.add_child(&child3);

    // Try to add a fourth child
    parent.add_child(&child4);

    auto children = parent.get_childrens();
    CHECK(children.size() == 3); // Only 3 children should be added
    CHECK(children[0]->getType() == 2);
    CHECK(children[1]->getType() == 3);
    CHECK(children[2]->getType() == 4);
}

TEST_CASE("Adding children to a node with existing children") {
    node<int> parent(1,3);
    node<int> child1(2,3);
    node<int> child2(3,3);

    parent.add_child(&child1);
    parent.add_child(&child2);

    node<int> newChild(4,3);
    parent.add_child(&newChild);

    auto children = parent.get_childrens();
    CHECK(children.size() == 3);
    CHECK(children[0]->getType() == 2);
    CHECK(children[1]->getType() == 3);
    CHECK(children[2]->getType() == 4);
}

// Tests on a relation of a tree
TEST_CASE("Tree hierarchy") {
    node<int> root(1);
    node<int> child1(2);
    node<int> child2(3);
    node<int> grandchild1(4);
    node<int> grandchild2(5);

    root.add_child(&child1);
    root.add_child(&child2);
    child1.add_child(&grandchild1);
    child2.add_child(&grandchild2);

    // Verify children of root
    auto rootChildren = root.get_childrens();
    CHECK(rootChildren.size() == 2);
    CHECK(rootChildren[0]->getType() == 2);
    CHECK(rootChildren[1]->getType() == 3);

    // Verify children of child1
    auto child1Children = child1.get_childrens();
    CHECK(child1Children.size() == 1);
    CHECK(child1Children[0]->getType() == 4);

    // Verify children of child2
    auto child2Children = child2.get_childrens();
    CHECK(child2Children.size() == 1);
    CHECK(child2Children[0]->getType() == 5);
}

//Tests on using max_size
TEST_CASE("Testing different max_size values") {
    node<int> parent1(1, 1); // max_size is 1
    node<int> child1(2);
    node<int> child2(3);

    parent1.add_child(&child1);
    // Should be able to add only one child
    parent1.add_child(&child2);

    auto children1 = parent1.get_childrens();
    CHECK(children1.size() == 1);
    CHECK(children1[0]->getType() == 2);

    node<int> parent2(4, 4); // max_size is 4
    node<int> childA(5);
    node<int> childB(6);
    node<int> childC(7);
    node<int> childD(8);

    parent2.add_child(&childA);
    parent2.add_child(&childB);
    parent2.add_child(&childC);
    parent2.add_child(&childD);

    // Should be able to add up to 4 children
    parent2.add_child(&child1); // Adding an additional child

    auto children2 = parent2.get_childrens();
    CHECK(children2.size() == 4);
    CHECK(children2[0]->getType() == 5);
    CHECK(children2[1]->getType() == 6);
    CHECK(children2[2]->getType() == 7);
    CHECK(children2[3]->getType() == 8);
}

// Tests on restarting the node
TEST_CASE("Re-initializing node") {
    node<int> parent(1);
    node<int> child1(2);
    node<int> child2(3);

    parent.add_child(&child1);
    parent.add_child(&child2);

    // Clear the children by creating a new node with the same type
    node<int> newParent(1);
    CHECK(newParent.get_childrens().empty()); // New node should have no children

    newParent.add_child(&child1);
    CHECK(newParent.get_childrens().size() == 1);
    CHECK(newParent.get_childrens()[0]->getType() == 2);
}


// Helper function to create a simple tree for testing
node<int>* create_test_tree() {
    node<int>* root = new node<int>(1);
    node<int>* child1 = new node<int>(2);
    node<int>* child2 = new node<int>(3);
    node<int>* child3 = new node<int>(4);

    root->add_child(child1);
    root->add_child(child2);
    root->add_child(child3);

    node<int>* grandchild1 = new node<int>(5);
    node<int>* grandchild2 = new node<int>(6);

    child1->add_child(grandchild1);
    child1->add_child(grandchild2);

    return root;
}




// A test to check the creation of a node
TEST_CASE("Creating a node") {
    node<int> n1(1);
    CHECK(n1.getType() == 1);
    CHECK(n1.get_max_size() == 2);
}

// A test to check the creation of a node with a different max_size
TEST_CASE("Creating a node with custom max_size") {
    node<int> n2(2, 5);
    CHECK(n2.getType() == 2);
    CHECK(n2.get_max_size() == 5);
}

// Test to check adding a child when there are no children
TEST_CASE("Adding child to node") {
    node<int> parent(3);
    node<int> child(4);
    parent.add_child(&child);
    auto children = parent.get_childrens();
    CHECK(children.size() == 1);
    CHECK(children[0]->getType() == 4);
}

// Test to check adding a child when the number of children has reached the maximum
TEST_CASE("Adding child when max_size is reached") {
    node<int> parent(5, 1);
    node<int> child1(6);
    node<int> child2(7);
    parent.add_child(&child1);
    parent.add_child(&child2);  //It will not be added because the max_size is 1
    auto children = parent.get_childrens();
    CHECK(children.size() == 1);  // Only child1 should be in the list
    CHECK(children[0]->getType() == 6);
}




// Tests for tree class

//Test to create a new tree
TEST_CASE("Creating a new tree") {
    tree<int> t1;
    CHECK(t1.get_root() == nullptr);
    CHECK(t1.get_length() == 2);
}

// A test for creating a tree with custom type and max_size
TEST_CASE("Creating a new tree with custom type and length") {
    tree<int> t2(10, 5);
    CHECK(t2.get_length() == 5);
}

// Test for adding a root
TEST_CASE("Adding a root node to the tree") {
    tree<int> t3;
    node<int> *n1=new node(1,2);
    t3.add_root(n1);
    CHECK(t3.get_root()->getType() == 1);

    // Trying to add another root (should fail)
    node<int> n2(2);
    t3.add_root(&n2); // An additional root should not be added
    CHECK(t3.get_root()->getType() == 1); // The first root should remain
}

// Test for adding a child to the tree
TEST_CASE("Adding a child node to a tree") {
    tree<int> t4;
    node<int> *root=new node(2);
    t4.add_root(root);
    node<int> *child=new node(3);
    t4.add_sub_node(t4, root, child);
    auto children = t4.get_root()->get_childrens();
    CHECK(children.size() == 1);
    CHECK(children[0]->getType() == 3);
}

// Test to check adding a child when the root is nullptr
TEST_CASE("Adding child when root is nullptr") {
    tree<int> t5;
    node<int> *child=new node(4);
    t5.add_sub_node(t5, nullptr, child);
    CHECK(t5.get_root() == nullptr);
}

// Test for checking items in DFS scans
TEST_CASE("DFS scan of the tree") {
    tree<int> t6(10, 3);
    node<int> *root=new node(5,3);
    t6.add_root(root);
    node<int> *child1=new node(6);
    node<int> *child2=new node(7);
    t6.add_sub_node(t6, root, child1);
    t6.add_sub_node(t6, root, child2);
    auto dfs_start = t6.begin_dfs_scan();
    auto dfs_end = t6.end_dfs_scan();
    CHECK(distance(dfs_start, dfs_end) == 3); // The root and the 2 children should be included
}

// Test for checking items in BFS scans
TEST_CASE("BFS scan of the tree") {
    tree<int> t7(15, 3);
    node<int> *root=new node(8,3);
    t7.add_root(root);
    node<int> *child1=new node(9);
    node<int> *child2=new node(10);
    t7.add_sub_node(t7, root, child1);
    t7.add_sub_node(t7, root, child2);
    auto bfs_start = t7.begin_bfs_scan();
    auto bfs_end = t7.end_bfs_scan();
    CHECK(distance(bfs_start, bfs_end) == 3); // The root and the 2 children should be included
}

// Test to check pre-order scans
TEST_CASE("Pre-order scan of the tree") {
    tree<int> t8(20, 3);
    node<int> *root=new node(11,3);
    t8.add_root(root);
    node<int> *child1=new node(12);
    node<int> *child2=new node(13);
    t8.add_sub_node(t8, root, child1);
    t8.add_sub_node(t8, root, child2);
    auto pre_order_start = t8.begin_pre_order();
    auto pre_order_end = t8.end_pre_order();
    CHECK(distance(pre_order_start, pre_order_end) == 3); // The root and the 2 children should be included
}

// Test for checking post-order scans
TEST_CASE("Post-order scan of the tree") {
    tree<int> t9(25, 3);
    node<int> *root=new node(14,3);
    t9.add_root(root);
    node<int> *child1=new node(15);
    node<int> *child2=new node(16);
    t9.add_sub_node(t9, root, child1);
    t9.add_sub_node(t9, root, child2);
    auto post_order_start = t9.begin_post_order();
    auto post_order_end = t9.end_post_order();
    CHECK(distance(post_order_start, post_order_end) == 3); // The root and the 2 children should be included
}

// Test to check adding children when the maximum has been reached
TEST_CASE("Adding child when max_size is reached") {
    tree<int> t10(30, 1);
    node<int> *root=new node(17,1);
    t10.add_root(root);
    node<int> *child1=new node(18);
    node<int> *child2=new node(19);
    t10.add_sub_node(t10, root, child1);
    t10.add_sub_node(t10, root, child2); // will not be added
    auto children = t10.get_root()->get_childrens();
    CHECK(children.size() == 1); // Only child1 should be in the list
    CHECK(children[0]->getType() == 18);
}



TEST_CASE("Testing complex_number class") {
    complex_number c1(3, 4);   // 3 + 4i
    complex_number c2(1, 2);   // 1 + 2i
    complex_number c3;         // 0 + 0i

    // Testing constructors
    CHECK(c1.get_real_number_number() == 3);
    CHECK(c1.get_imag_number() == 4);
    CHECK(c2.get_real_number_number() == 1);
    CHECK(c2.get_imag_number() == 2);
    CHECK(c3.get_real_number_number() == 0);
    CHECK(c3.get_imag_number() == 0);

    // Testing magnitude
    CHECK(c1.magnitude_complex() == 5.0);
    CHECK(c2.magnitude_complex() == 2.23606797749979); // Calculated value of sqrt(5)

    // Testing addition
    complex_number c4 = c1 + c2; // (3 + 1) + (4 + 2)i = 4 + 6i
    CHECK(c4.get_real_number_number() == 4);
    CHECK(c4.get_imag_number() == 6);

    // Testing subtraction
    complex_number c5 = c1 - c2; // (3 - 1) + (4 - 2)i = 2 + 2i
    CHECK(c5.get_real_number_number() == 2);
    CHECK(c5.get_imag_number() == 2);

    // Testing multiplication
    complex_number c6 = c1 * c2; // (3*1 - 4*2) + (3*2 + 4*1)i = -5 + 10i
    CHECK(c6.get_real_number_number() == -5);
    CHECK(c6.get_imag_number() == 10);

    // Testing division
    complex_number c7 = c1 / c2; // ((3*1 + 4*2) / (1*1 + 2*2)) + ((4*1 - 3*2) / (1*1 + 2*2))i = 2.2 + 0.4i
    CHECK(c7.get_real_number_number() == 2.2);
    CHECK(c7.get_imag_number() == -0.4);

    // Testing equality
    complex_number c8(3, 4);
    CHECK(c1 == c8);
    CHECK(c1 != c2);

    // Testing unary minus
    complex_number c9 = -c1; // -3 - 4i
    CHECK(c9.get_real_number_number() == -3);
    CHECK(c9.get_imag_number() == -4);

    // Testing compound assignment operators
    c1 += c2; // (3+1) + (4+2)i = 4 + 6i
    CHECK(c1.get_real_number_number() == 4);
    CHECK(c1.get_imag_number() == 6);

    c1 -= c2; // (4-1) + (6-2)i = 3 + 4i
    CHECK(c1.get_real_number_number() == 3);
    CHECK(c1.get_imag_number() == 4);

    c1 *= c2; // (3*1 - 4*2) + (3*2 + 4*1)i = -5 + 10i
    CHECK(c1.get_real_number_number() == -5);
    CHECK(c1.get_imag_number() == 10);

    c1 /= c2; // ((-5*1 + 10*2) / (1*1 + 2*2)) + ((10*1 - (-5*2)) / (1*1 + 2*2))i = 2.2 + 0.4i

    // Testing comparison operators
    CHECK(c2 < c1);
    CHECK(c2 <= c1);
    CHECK(c1 > c2);
    CHECK(c1 >= c2);

}