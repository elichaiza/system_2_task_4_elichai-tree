//elichaiza@gmail.com
//ID:318691821

#ifndef TREE_H
#define TREE_H
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
#include"node.hpp"
#include <SFML/Graphics.hpp>
#include <queue>

using namespace std;

template <typename  T,int a=2>

class tree {
private:
    T type;
    int max_size;
    node<T> *root;

    // hear i create a vector of nodes for all the prints of the dfs,bfs,pre_order...
    vector<node<T>*> pre_order_vector;
    vector<node<T>*> post_order_vector;
    vector<node<T>*> in_order_vector;
    vector<node<T>*> bfs_vector;
    vector<node<T>*> dfs_vector;
    vector<node<T>*> heap_vector;

public:
    tree(T type, int length) {
        this->type = type;
        this->max_size = length;
        this->root = nullptr;
        cout << "Creating a new tree" << endl;
    }


    tree(){
        root=nullptr;
        cout<<"Creating a new tree"<<endl;
    }

    tree(T type) {
        this->type=type;
        this->max_size=2;
        cout<<"Creating a new tree"<<endl;
    }

    ~tree(){
        tree_destructor(root);
    }

    void tree_destructor(node<T> *_node){
        if (_node == nullptr)
            return;
        for (auto children : _node->get_childrens()){
            tree_destructor(children);
        }
        delete _node;
    }

    int get_length() {
        return this->max_size;
    }

    node<T>* get_root() {
        return this->root;
    }

    vector<node<T>*> get_pre_order_vector() {
        return this->pre_order_vector;
    }
    vector<node<T>*> get_post_order_vector() {
        return this->post_order_vector;
    }
    vector<node<T>*> get_in_order_vector() {
        return this->in_order_vector;
    }
    vector<node<T>*> get_bfs_vector() {
        return this->bfs_vector;
    }
    vector<node<T>*> get_dfs_vector() {
        return this->dfs_vector;
    }
    vector<node<T>*> get_heap_vector(){return this->heap_vector;}


    // adding the root of the tree

    void add_root(node<T> *root) {
        if (root == nullptr) {
            cout << "Cannot add a nullptr as root" << endl;
            return;
        }
        if (this->root != nullptr) {
            cout << "The root already exists" << endl;
            return;
        }
        this->root = root;
        cout<<"the root edding successfully" << endl;
    }

    // adding sun to the father
    void add_sub_node(tree<T, a> &tree, node<T> *father, node<T> *children) {
        if (tree.root == nullptr) {
            cout << "We don't have a root, so we can't add a child" << endl;
            return;
        }
        if (tree.root == father) {
            tree.root->add_child(children);
            return;
        }
        bool ans = false;
        vector<node<T>*> chilren_of_root=tree.root->get_childrens();

        find_node_and_adding_to_him_child(ans, chilren_of_root, father, children);
        if (ans) {
            cout << "The child has successfully joined " << endl;
        } else {
            cout << "The child did not join either because there was no room or because the father was not found" << endl;
        }
    }


    bool find_node_and_adding_to_him_child(bool &ans,vector<node<T>*> chilren_of_root, node<T> *father, node<T> *children) {
        for(size_t i = 0; i < a; i++) {
            if(chilren_of_root[i]==father) {
                chilren_of_root[i]->add_child(children);
                ans = true;
                return ans;
            }
        }
        for(size_t i = 0; i < a; i++) {
            find_node_and_adding_to_him_child(ans, chilren_of_root[i]->get_childrens(), father, children);
        }
        return ans;
    }


    typename vector<node<T>*>::iterator  begin_pre_order() {
        if(this->root->get_max_size()!=2) {
            return begin_dfs_scan();
        }
        pre_order_vector.clear();
        pre_order_calculation(this->root,pre_order_vector);
        return pre_order_vector.begin();
    }

    void pre_order_calculation(node<T> *root, vector<node<T>*> &ans){
        if (root == nullptr) {
            return;
        }
        ans.push_back(root);
         vector<node<T>*> childerns=root->get_childrens();
       for(size_t i=0;i<childerns.size();i++) {
           pre_order_calculation(childerns[i],ans);
       }
    }

    typename vector<node<T> *>::iterator end_pre_order(){
        if (this->root->get_max_size()!=2){
            return end_dfs_scan();
        }
        return pre_order_vector.end();
    }

    typename vector<node<T>*> ::iterator begin_post_order() {
        if(this->root->get_max_size()!=2) {
            return begin_dfs_scan();
        }
        post_order_vector.clear();
        post_order_calculation(this->root,post_order_vector);
        return post_order_vector.begin();
    }

    void post_order_calculation(node<T> *root, vector<node<T>*> &ans) {
        if (root == nullptr) {
            return;
        }
        for (auto children : root->get_childrens()){
            post_order_calculation(children, ans);
        }
        ans.push_back(root);
    }
    typename vector<node<T> *>::iterator end_post_order(){
        if (this->root->get_max_size()!=2){
            return end_dfs_scan();
        }
        return post_order_vector.end();
    }


    typename vector<node<T>*> ::iterator  begin_in_order() {
        if(this->root->get_max_size()!=2) {
            return begin_dfs_scan();
        }
        in_order_vector.clear();
        post_order_calculation(this->root,post_order_vector);
        return post_order_vector.begin();
    }

    void in_order_calculation(node<T> *root, vector<node<T>*> &ans) {
        if (root == nullptr) {
            return;
        }
        auto children = root->get_children();
        if (children.size() > 0) {
            in_order_helper(children[0], ans); // Left child
        }
        ans.push_back(root); // Root
        if (children.size() > 1) {
            in_order_helper(children[1], ans); // Right child
        }
    }
    typename vector<node<T>*>::iterator end_in_order(){
        if (this->root->get_max_size()!=2){
            return end_dfs_scan();
        }
        return in_order_vector.end();
    }

    typename vector<node<T>*>::iterator  begin_bfs_scan() {
        bfs_vector.clear();
        bfs(root, bfs_vector);
        return bfs_vector.begin();
    }

    void bfs(node<T>*root, vector<node<T>*> &ans) {
        if (root == nullptr)
            return;
        queue<node<T> *> tmp;
        tmp.push(root);
        while (!tmp.empty()){
            node<T> *node_front = tmp.front();
            tmp.pop();
            ans.push_back(node_front);
            for (auto children : node_front->get_childrens()){
                tmp.push(children);
            }
        }
    }

    typename vector<node<T>*>::iterator end_bfs_scan(){
        return bfs_vector.end();
    }



    typename vector<node<T>*>::iterator  begin_dfs_scan() {
        dfs_vector.clear();
        dfs(root, dfs_vector);
        return dfs_vector.begin();
    }

    void dfs(node<T> *root, vector<node<T> *> ans) {
        if (root == nullptr)
            return;
        ans.push_back(root);
        for (auto child : root->get_childrens()) {
            dfs(child, ans);
        }
    }

    typename vector<node<T> *>::iterator end_dfs_scan(){
        return dfs_vector.end();
    }

    typename vector<node<T> *>::iterator begin_heap(){
        heap_vector.clear();
        myHeap(root, heap_vector);
        return heap_vector.begin();
    }

    void myHeap(node<T> *root, vector<node<T>*> &ans){
        if (root == nullptr) // היה צריך להיות nullptr
            return;
        dfs(root, ans);
        auto comp = [](node<T> *L, node<T> *R) { return L->get_value() > R->get_value(); };
        make_heap(ans.begin(), ans.end(), comp);
    }

    typename vector<node<T> *>::iterator end_heap(){
        return heap_vector.end();
    }

    //GUI:
    void draw_node(node<T>* current, sf::RenderWindow& window, sf::Font& font, float x, float y, float offsetX, float offsetY) {
        if (!current) return;

        // Draw the current node
        sf::CircleShape nodeShape(27);
        nodeShape.setPosition(x-11, y-8);
        nodeShape.setFillColor(sf::Color::Blue);
        window.draw(nodeShape);

        // Create text for the node
        sf::Text text;
        text.setFont(font);
        if constexpr (std::is_same<T, std::string>::value) {
            text.setString(current->getType());
        } else {
            std::ostringstream oss;
            oss << std::fixed << std::setprecision(1) << current->getType();
            text.setString(oss.str());
        }
        text.setCharacterSize(25);
        text.setFillColor(sf::Color::White);
        text.setOrigin(text.getLocalBounds().width / 2, text.getLocalBounds().height / 2);
        text.setPosition(x + 27 / 2, y + 27 / 2);

        window.draw(text);

        // Draw children nodes and lines
        auto children = current->get_childrens();
        float childX = x - (children.size() - 1) * offsetX / 2;
        for (auto child : children) {
            sf::Vertex line[] = {
                sf::Vertex(sf::Vector2f(x + 30 / 2, y + 30 / 2)),
                sf::Vertex(sf::Vector2f(childX + 30 / 2, y + offsetY + 30 / 2))
            };
            window.draw(line, 2, sf::Lines);
            draw_node(child, window, font, childX, y + offsetY, offsetX / 2, offsetY);
            childX += offsetX;
        }
    }

    void draw(sf::RenderWindow& window) {
        // Load font
        sf::Font font;
        if (!font.loadFromFile("arial.ttf")) {
            std::cerr << "Failed to load font file 'arial.ttf'" << std::endl;
            return;
        }

        window.clear();
        draw_node(this->root, window, font, 400, 60, 150, 150);  // Draw the tree starting from the root
        window.display();
    }
};



#endif //TREE_H
