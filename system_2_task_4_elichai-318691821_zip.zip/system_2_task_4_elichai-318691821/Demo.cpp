
//elichaiza@gmail.com
//ID:318691821
/**
 * Demo app for Ex4
 */
#include <iostream>
#include <string>
#include "node.hpp"
#include "tree.hpp"
#include "complex_number.h"
#include <SFML/Graphics.hpp>


using namespace std;


int main(){
    tree <double> my_tree; // Binary tree that contains doubles.
    node <double> *root_node=new node(1.1);

    my_tree.add_root(root_node);
    node<double> *n1 =new node(1.2);
    node<double> *n2 = new node(1.3);
    node<double> *n3 = new node(1.4);
    node<double> *n4 = new node(1.5);
    node<double> *n5 = new node(1.6);

    my_tree.add_sub_node(my_tree,root_node, n1);
    my_tree.add_sub_node(my_tree,root_node, n2);
    my_tree.add_sub_node(my_tree,n1, n3);
    my_tree.add_sub_node(my_tree,n1, n4);
    my_tree.add_sub_node(my_tree,n2, n5);

    // The tree should look like:
    /**
     *       root = 1.1
     *     /       \
     *    1.2      1.3
     *   /  \      /
     *  1.4  1.5  1.6
     */

    my_tree.begin_pre_order();
    cout<<"printing the pre order vector:"<<endl;

    for(size_t i=0;i<my_tree.get_pre_order_vector().size();i++) {
        cout <<my_tree.get_pre_order_vector()[i]->getType()<<","<< endl;
    }
    my_tree.end_pre_order();
      //  cout << node->getType() << endl;
     // prints: 1.1, 1.2, 1.4, 1.5, 1.3, 1.6

    my_tree.begin_post_order();
    cout<<"printing the post order vector:"<<endl;

    for(size_t i=0;i<my_tree.get_post_order_vector().size();i++) {
    cout <<my_tree.get_post_order_vector()[i]->getType()<<","<< endl;
    }
    my_tree.end_post_order();
     // prints: 1.4, 1.5, 1.2, 1.6, 1.3, 1.1

    my_tree.begin_in_order();
    cout<<"printing the in order vector:"<<endl;

    vector<node<double>*> in=my_tree.get_in_order_vector();
    for(size_t i=0;i<in.size();i++) {
        cout <<in[i]<<","<< endl;
    }
    my_tree.end_in_order();
     // prints: 1.4, 1.2, 1.5, 1.1, 1.6, 1.3

    my_tree.begin_bfs_scan();
    for(size_t i=0;i<my_tree.get_bfs_vector().size();i++) {
        cout <<my_tree.get_bfs_vector()[i]->getType()<<","<< endl;
    }
    my_tree.end_bfs_scan();
    // prints: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6

    cout<<"printing the childrens of the tree:"<<endl;
   cout << my_tree.get_root()->getType()<< endl;
    for (auto node : my_tree.get_root()->get_childrens())
    {
        cout << node->getType() << endl;
    } // same as BFS: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6

    sf::RenderWindow window(sf::VideoMode(800, 600), "Tree Visualization");
    // לולאת הציור של חלון ה-SFML
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        window.clear();
        my_tree.draw(window);
        window.display();
    }

    //cout << my_tree.draw_node(my_tree.get_root(),); // Should print the graph using GUI.

    // יצירת אובייקט של מחלקת tree עם טיפוס double וגדול 3
    tree<double, 3> three_ary_tree(0.0, 3);// 3-ary tree.

    node <double> *root_node2=new node(1.1,3);
    three_ary_tree.add_root(root_node2);
    node<double> *n21 =new node(1.2,3);
    node<double> *n22 = new node(1.3,3);
    node<double> *n23 = new node(1.4,3);
    node<double> *n24 = new node(1.5,3);
    node<double> *n25 = new node(1.6,3);

    three_ary_tree.add_sub_node(three_ary_tree,root_node2, n21);
    three_ary_tree.add_sub_node(three_ary_tree,root_node2, n22);
    three_ary_tree.add_sub_node(three_ary_tree,root_node2, n23);
    three_ary_tree.add_sub_node(three_ary_tree,n21, n24);
    three_ary_tree.add_sub_node(three_ary_tree,n22, n25);

     // The tree should look like:
    /**
     *       root = 1.1
     *     /      |     \
     *    1.2    1.3    1.4
     *   /        |
     *  1.5      1.6
     */
    sf::RenderWindow window2(sf::VideoMode(800, 600), "Tree Visualization");
    // לולאת הציור של חלון ה-SFML
    while (window2.isOpen()) {
        sf::Event event;
        while (window2.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window2.close();
        }

        window2.clear();
        three_ary_tree.draw(window2);
        window2.display();
    }



    tree<complex_number, 3> complex_tree(complex_number(1.0,1.0), 3);

    complex_number complex_num1(1.0,1.0);
    complex_number complex_num2(1.5,2.2);
    complex_number complex_num3(2.3,3.1);
    complex_number complex_num4(3.4,2.8);
    complex_number complex_num5(3.6,4.7);
    complex_number complex_num6(4.1,3.4);
    complex_number complex_num7(4.9,4.9);

    node<complex_number> *complex_node0 =new node(complex_num1,3);
    node<complex_number> *complex_node1 =new node(complex_num2,3);
    node<complex_number> *complex_node2 = new node(complex_num3,3);
    node<complex_number> *complex_node3 = new node(complex_num4,3);
    node<complex_number> *complex_node4 = new node(complex_num5,3);
    node<complex_number> *complex_node5 = new node(complex_num6,3);
    node<complex_number> *complex_node6 = new node(complex_num7,3);

    complex_tree.add_root(complex_node0);

    complex_tree.add_sub_node(complex_tree,complex_node0,complex_node1);
    complex_tree.add_sub_node(complex_tree,complex_node0,complex_node2);
    complex_tree.add_sub_node(complex_tree,complex_node0,complex_node3);
    complex_tree.add_sub_node(complex_tree,complex_node1,complex_node4);
    complex_tree.add_sub_node(complex_tree,complex_node1,complex_node5);
    complex_tree.add_sub_node(complex_tree,complex_node1,complex_node6);

    for(size_t i=0; i<complex_tree.get_in_order_vector().size();i++){
        cout<<complex_tree.get_in_order_vector()[i]<<endl;
    }
    // The tree should look like:
    /**
     *          root = 1,1i
     *         /      |     \
     *    1.5,2.2i 2.3,3.1i 3.4,2.8i
     *       /
     *      3,2
     *     /      |      \
     *3.6,4.7i 4.1,3.9i  4.9,4.9i
     */
    //
    sf::RenderWindow window3(sf::VideoMode(800, 600), "complex_tree");
    // לולאת הציור של חלון ה-SFML
    while (window3.isOpen()) {
        sf::Event event;
        while (window3.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window3.close();
        }

        window3.clear();
        complex_tree.draw(window3);
        window3.display();
    }


    return 0;
}

