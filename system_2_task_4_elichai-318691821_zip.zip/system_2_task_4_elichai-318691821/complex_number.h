//
// Created by elich on 8/5/2024.
//

#ifndef complex_number_NUMBER_H
#define complex_number_NUMBER_H

#include <iostream>
#include <cmath>
#include <complex>
using namespace std;

class complex_number{
    ////The numbers that represent the complex number
    private:
        double real_number;
        double imaginary_number;

    public:
        //Constructor of the class
        complex_number(double r, double i) {
            real_number=r;
            imaginary_number=i;
        }
        complex_number() : real_number(0.0), imaginary_number(0.0) {}

        //Returns the real number
        double get_real_number_number() const {
            return real_number;
        }
        // Returns the imaginary number
        double get_imag_number() const {
            return imaginary_number;
        }

    //A function that calculates the length of the vector representing the complex number
        double magnitude_complex() const {
            return sqrt(real_number * real_number + imaginary_number * imaginary_number);
        }

    //operators::

        complex_number operator+(const complex_number &complex_num) const {
            return complex_number(real_number + complex_num.real_number, imaginary_number + complex_num.imaginary_number);
        }
    
        complex_number operator-(const complex_number &complex_num) const {
            return complex_number(real_number - complex_num.real_number, imaginary_number - complex_num.imaginary_number);
        }

        complex_number operator*(const complex_number &complex_num) const {
            return complex_number(real_number * complex_num.real_number - imaginary_number * complex_num.imaginary_number, real_number * complex_num.imaginary_number + imaginary_number * complex_num.real_number);
        }

        complex_number operator/(const complex_number &complex_num) const {
            double denominator = complex_num.real_number * complex_num.real_number + complex_num.imaginary_number * complex_num.imaginary_number;
            return complex_number((real_number * complex_num.real_number + imaginary_number * complex_num.imaginary_number) / denominator, (imaginary_number * complex_num.real_number - real_number * complex_num.imaginary_number) / denominator);
        }

        bool operator==(const complex_number &complex_num) const {
            return real_number == complex_num.real_number && imaginary_number == complex_num.imaginary_number;
        }

        bool operator!=(const complex_number &complex_num) const {
            return !(*this == complex_num);
        }

        complex_number operator-() const {
            return complex_number(-real_number, -imaginary_number);
        }

        complex_number operator+=(const complex_number &complex_num) {
            real_number += complex_num.real_number;
            imaginary_number += complex_num.imaginary_number;
            return *this;
        }

        complex_number operator-=(const complex_number &complex_num) {
            real_number -= complex_num.real_number;
            imaginary_number -= complex_num.imaginary_number;
            return *this;
        }

        complex_number operator*=(const complex_number &complex_num) {
            double real = real_number;
            real_number = real_number * complex_num.real_number - imaginary_number * complex_num.imaginary_number;
            imaginary_number = real * complex_num.imaginary_number + imaginary_number * complex_num.real_number;
            return *this;
        }

        complex_number operator/=(const complex_number &complex_num) {
            double denominator = complex_num.real_number * complex_num.real_number + complex_num.imaginary_number * complex_num.imaginary_number;
            double real = real_number;
            real_number = (real_number * complex_num.real_number + imaginary_number * complex_num.imaginary_number) / denominator;
            imaginary_number = (imaginary_number * complex_num.real_number - real * complex_num.imaginary_number) / denominator;
            return *this;
        }

        bool operator<(const complex_number &complex_num) const {
            return magnitude_complex() < complex_num.magnitude_complex();
        }

        bool operator<=(const complex_number &complex_num) const {
            return magnitude_complex() <= complex_num.magnitude_complex();
        }

        bool operator>(const complex_number &complex_num) const {
            return magnitude_complex() > complex_num.magnitude_complex();
        }

        bool operator>=(const complex_number &complex_num) const {
            return magnitude_complex() >= complex_num.magnitude_complex();
        }

        friend ostream& operator<<(ostream &out, const complex_number &complex_num) {
            out << complex_num.real_number << " + " << complex_num.imaginary_number << "i";
            return out;
        }

};



#endif //complex_number_NUMBER_H
