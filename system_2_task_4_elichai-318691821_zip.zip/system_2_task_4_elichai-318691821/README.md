                      עצים - STL, Templates, and Iterators
//elichaiza@gmail.com
//ID:318691821

במטלה זו התבקשו ליצור עצים בעזרת קויינטיינר בעזרת כמה מחלקות: node,tree,complex_number
במחלקת הnode קיימים לנו כמה פונקציות עיקרות:
1)T getType()  -  מחזיר לנו את סוג הnode  שיצרנו 
2)int get_max_size()   - מזחיר לנו את הגודל המקבימלי של הבנים אליו נוכל להכניס לכל node
3)get_childrens()  -מחזיר לנו את הילדים של אותו הnode הספציפי
4)add_child( node *child) - מוסיך ילד לעלה.

במחלקת הtree קיימים לנו כמה פונקציות עיקריות:
1) get_length()
2) get_root()
3) get_pre_order_vector()
4) get_post_order_vector()
4) get_in_order_vector()
5) get_bfs_vector()
6) get_dfs_vector()
7) get_heap_vector()
8) add_root(node<T> *root)
9)  add_sub_node(.....)
10)  find_node_and_adding_to_him_child(...)
11) begin_pre_order()
12) pre_order_calculation(...)
13) end_pre_order()
14) begin_post_order()
15) end_post_order()
16) begin_in_order() 
17) in_order_calculation(...)
18) end_in_order()
19) begin_bfs_scan()
20) bfs(...)
21) end_bfs_scan()
22) begin_dfs_scan()
23) dfs(...)
24) end_dfs_scan()
25)  begin_heap()
26) myHeap(..)
27)  end_heap()
28)  draw_node(..)
29) draw(..)
כל הפונקציות האלו משמשים לחישוב כל השימושיות בעצים כולל מיון ויצירת אובייקטים

מחלקת complex_numberיש לה כמה פונקציות עיקריות:
1) get_real_number_number()
2) get_imag_number()
3) magnitude_complex()
וקיימים בה עוד הרבה אופרטורים אשר איתם כמובן נוכל להשתמש בכל הפונקציונאליות של מספר מרוכב 
 למשל כמו מספר מרוכב + מספר מרוכב
ובנוסך יש את קובץ הDemo שהוא מראה לנו הפעלה של כל המחלקות האלו ודוגמאות
ולבסוף עשיתי מחלקת טסטים אשר בודקת את כל המחלקות שמניתי למעלה.
השתמשי בתור GUI בסיפרייה של <SFML/Graphics.hpp> כי התייעצתי עם כמה חברים לתואר במה כדיי להשתמש והמליצו לי הרבה על זה 
. אז למדתי על הסיפרייה הזו והשתמשתי בה
 